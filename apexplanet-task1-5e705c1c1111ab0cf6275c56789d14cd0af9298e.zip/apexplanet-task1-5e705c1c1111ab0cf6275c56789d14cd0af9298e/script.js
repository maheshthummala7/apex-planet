function showMotivation() {
  alert("🚀 Keep going! Every line of code brings you closer to mastery. 💻✨");
}
